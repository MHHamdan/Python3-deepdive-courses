print('executing pack1...')
value = 'pack1 value'

import pack1.pack1_1
