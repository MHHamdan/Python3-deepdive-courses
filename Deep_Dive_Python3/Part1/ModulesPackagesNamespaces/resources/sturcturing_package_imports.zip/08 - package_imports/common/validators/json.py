# json.py

__all__ = ['is_json']


def is_json(arg):
    pass


def json_helper_1():
    pass


def json_helper_2():
    pass
