# calculator.py

__all__ = ['Calc']


class Calc:
    pass


def calc_helper_1():
    pass
