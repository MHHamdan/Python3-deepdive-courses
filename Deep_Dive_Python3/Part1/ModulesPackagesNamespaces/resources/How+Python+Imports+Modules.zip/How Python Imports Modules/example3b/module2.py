# module2.py

print('Running module2.py')
import module1

def hello():
    print('module2 says Hello!\nand...')
    module1.hello()

